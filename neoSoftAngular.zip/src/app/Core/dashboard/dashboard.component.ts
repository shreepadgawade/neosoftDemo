import { Component, OnInit } from '@angular/core';
import { DashboardService } from "../../services/dashboard.service";
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  posts: any;
  constructor(private DashboardService: DashboardService) { }

  ngOnInit(): void {
    this.initDashboard();
  }

  jsonFlickrApi(rsp) {
    return rsp;
  }

  initDashboard() {
    this.DashboardService.getAllPosts()
      .subscribe(data => {
        this.posts = data.items;
        console.log(this.posts)
      })   
  }

}
