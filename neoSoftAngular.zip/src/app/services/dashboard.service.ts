import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  configUrl = "https://api.flickr.com/services/feeds/photos_public.gne?format=json&jsoncallback=JSONP_CALLBACK";
  constructor(private http: HttpClient) { }

  getAllPosts() : Observable <any> {
    return  this.http.jsonp(this.configUrl, 'JSONP_CALLBACK');
  }

}
