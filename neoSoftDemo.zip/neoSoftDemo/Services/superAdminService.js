"use strict";
exports.__esModule = true;
var nodeify = require('nodeify');
var requestNpm = require('request');
var superAdminService = /** @class */ (function () {
    function superAdminService() {
        /**
         * function name : getLocation
         *
        //  * @param {number} paramNameId Description.
         */
        this.getflickrImages = function (request, callback) {
            return nodeify(new Promise(function (resolve, reject) {
                // we can add validation here
                requestNpm('https://www.flickr.com/services/feeds/photos_public.gne?format=json', function (err, res, body) {
                    if (err) {
                        return reject(err);
                    }
                    return resolve(res);
                });
            }), callback);
        };
    }
    return superAdminService;
}());
exports.superAdminServices = new superAdminService();
