var nodeify  = require('nodeify');
var requestNpm = require('request');

class superAdminService {
  
  constructor() {
   
  }
  
  /**
   * function name : getLocation
   *
  //  * @param {number} paramNameId Description.
   */
  public getflickrImages = function (request, callback) {
    return nodeify(
        new Promise((resolve, reject) => { 
          
          // we can add validation here

          requestNpm('https://www.flickr.com/services/feeds/photos_public.gne?format=json', (err, res, body) => {
            if (err) { return reject(err); }
            return resolve(res);
          });
            
        }), callback);
  }

    
}

export let superAdminServices = new superAdminService();
