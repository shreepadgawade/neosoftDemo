var express = require('express');
var router = express.Router();
var superAdminRequest = require('../Services/superAdminService').superAdminServices;

router.get('/getflickrImages', function(req, res, next) {
  superAdminRequest.getflickrImages(req.body).then(response =>{
    res.send(response);
  }).catch(error => {
    console.log(error);
    res.status(500).send({ error: error });
  })
});



module.exports = router;
